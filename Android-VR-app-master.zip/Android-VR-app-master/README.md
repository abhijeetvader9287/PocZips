# Android-VR-app
This is a 360 degree image viewer app.

This app is from the inspiration of a Google codelabs projects. The features of the app will be to browse and select an image from the phone and can be seen 360 degree viewer without the cardboard.
