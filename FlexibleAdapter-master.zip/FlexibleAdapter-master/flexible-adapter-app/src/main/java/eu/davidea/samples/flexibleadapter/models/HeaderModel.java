package eu.davidea.samples.flexibleadapter.models;

/**
 * Model item for HeaderHolder.
 *
 * @author Davide Steduto
 * @since 19/10/2016
 */
public class HeaderModel extends AbstractModel {

    public HeaderModel(String id) {
        super(id);
    }

}