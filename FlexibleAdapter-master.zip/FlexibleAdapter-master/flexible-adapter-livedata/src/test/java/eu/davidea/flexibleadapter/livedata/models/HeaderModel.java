package eu.davidea.flexibleadapter.livedata.models;

/**
 * Model item for HeaderHolder.
 *
 * @author Davide Steduto
 * @since 07/10/2017
 */
public class HeaderModel extends AbstractModel {

    public HeaderModel(String id) {
        super(id);
    }

}