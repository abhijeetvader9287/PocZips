package com.sunmi.sunmit2demo.eventbus;

public class InstallSmileEvent {
}
