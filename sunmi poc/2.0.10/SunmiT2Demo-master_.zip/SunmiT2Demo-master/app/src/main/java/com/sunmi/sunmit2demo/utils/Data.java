package com.sunmi.sunmit2demo.utils;

/**
 * 数据实体
 * 
 * @author longtao.li
 */
public class Data {

	public DataModel dataModel; // 数据模型

	public String data;
}
