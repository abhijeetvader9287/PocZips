package openapi;

/**
 * Created by yueweizyw on 17/9/25.
 */
public class AlipayApiException extends Throwable {
    public AlipayApiException(Exception e) {}
}
