package com.sunmi.sunmit2demo.fragment;

import android.os.Bundle;
import android.view.View;

import com.sunmi.sunmit2demo.BaseFragment;

public class HandSettingFragment extends BaseFragment{
    @Override
    protected int setView() {
        return 0;
    }

    @Override
    protected void init(View view) {

    }

    @Override
    protected void initData(Bundle savedInstanceState) {

    }
}
