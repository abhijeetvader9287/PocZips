//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.sunmi.sunmit2demo.eventbus;

public class UnlockSuccessEvent {
    private String address;

    public UnlockSuccessEvent(String var1) {
        this.address = var1;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String var1) {
        this.address = var1;
    }
}
