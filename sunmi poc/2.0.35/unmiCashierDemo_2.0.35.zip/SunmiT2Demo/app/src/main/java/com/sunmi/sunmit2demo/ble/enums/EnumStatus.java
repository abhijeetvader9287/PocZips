package com.sunmi.sunmit2demo.ble.enums;

/**
 * Created by yaoh on 2018/11/16.
 */

public enum EnumStatus {
    STATUS_SCAN_SUCCESS,
    STATUS_SCAN_FAILED,
    STATUS_BLE_NOT_OPEN,
}
