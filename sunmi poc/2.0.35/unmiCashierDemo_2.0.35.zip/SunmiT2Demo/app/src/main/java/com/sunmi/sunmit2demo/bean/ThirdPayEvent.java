package com.sunmi.sunmit2demo.bean;

/**
 * Created by Paragon-xzm on 2018/5/20 20:32
 */

public class ThirdPayEvent{


    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    boolean result;


}
