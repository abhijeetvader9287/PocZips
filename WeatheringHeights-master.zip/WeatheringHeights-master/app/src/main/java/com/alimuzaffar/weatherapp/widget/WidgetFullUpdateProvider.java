package com.alimuzaffar.weatherapp.widget;

/**
 * Created by Ali Muzaffar on 17/11/2015.
 */
public class WidgetFullUpdateProvider extends WidgetUpdateProvider {
}
