package com.alimuzaffar.weatherapp.widget;

import android.graphics.Color;

/**
 * Created by Ali Muzaffar on 17/11/2015.
 */
public class WidgetFullDarkUpdateProvider extends WidgetUpdateProvider {
    @Override
    public int getTextColor() {
        return Color.BLACK;
    }
}
