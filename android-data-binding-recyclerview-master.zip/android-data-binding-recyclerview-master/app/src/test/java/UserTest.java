import net.droidlabs.mvvmdemo.model.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class UserTest
{
    @Test
    public void test()
    {
        User user = new User("a", "b");


    }
}
