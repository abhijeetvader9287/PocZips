package net.droidlabs.mvvm.recyclerview.adapter;

public interface ClickHandler<T>
{
    void onClick(T viewModel);
}