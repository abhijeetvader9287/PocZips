package net.droidlabs.mvvm.recyclerview.adapter;

public interface LongClickHandler<T>
{
    void onLongClick(T viewModel);
}
