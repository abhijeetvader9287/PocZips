package com.example.sneha.myapplication;

public interface ButtonClickActionInterface {

    public void nextButtonClick(int pos);
}
