package com.example.sneha.myapplication.curlPaheLib;

public interface PageCurl {


    void setCurlFactor(float curl);

}
