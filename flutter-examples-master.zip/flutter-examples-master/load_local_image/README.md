# Load Local Image

Example app showing implementation which loads up an image from a local folder.

<img src="demo_img.jpg" height="600em" />


## Getting Started

For help getting started with Flutter, view online [documentation](http://flutter.io/).