# Using Gradients

Example app showing implementing gradient as a background.

<img src="demo_img.jpg" height="600em" />


## Getting Started

For help getting started with Flutter, view online [documentation](http://flutter.io/).