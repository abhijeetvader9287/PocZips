# Using Http GET

Example app showing implementation which loads up an information via making an HTTP GET call to a server and then displays the results in a list form.

<img src="demo_img.gif" height="600em" />


## Getting Started

For help getting started with Flutter, view online [documentation](http://flutter.io/).