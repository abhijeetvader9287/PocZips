# Load Local JSON

Example app showing implementation which loads up a json file from a local folder.

<img src="demo_img.gif" height="600em" />


## Getting Started

For help getting started with Flutter, view online [documentation](http://flutter.io/).