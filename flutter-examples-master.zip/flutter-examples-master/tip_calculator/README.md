# Tip Calculator

Example app showing implementation which calculates the tip.

<img src="demo_img.gif" height="600em" />


## Getting Started

For help getting started with Flutter, view online [documentation](http://flutter.io/).