# Using Themes

Example app that shows how to setup a theme in your app.

<img src="demo_img.jpg" height="600em" />


## Getting Started

For help getting started with Flutter, view online [documentation](http://flutter.io/).