# Using Edit Text

Example app that shows how to use a Edit Text in an app.

<img src="demo_img.gif" height="600em" />


## Getting Started

For help getting started with Flutter, view online [documentation](http://flutter.io/).