# Google Signin

Example app to demonstrate Google signin using Firebase. Register your app on Firebase and enable Google authentication.

![Initial Page](page1.jpg)
![Login Dialog](page2.jpg)
![User Page](page3.jpg)

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
