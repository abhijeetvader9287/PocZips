package com.learn2crack.retrofitkotlin.model

data class Android(val name : String, val version : String, val apiLevel : String)