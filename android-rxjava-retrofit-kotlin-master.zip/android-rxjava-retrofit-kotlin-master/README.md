# android-rxjava-retrofit-kotlin

This is sample project which uses Retrofit and RxJava in Kotin to parse JSON data from the following URL,

https://learn2crack-json.herokuapp.com/api/android

Complete Tutorial on,
https://www.learn2crack.com/2017/11/retrofit-and-rxjava-in-kotlin.html
