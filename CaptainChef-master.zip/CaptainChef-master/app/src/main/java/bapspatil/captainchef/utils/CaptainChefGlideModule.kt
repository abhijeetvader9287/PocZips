package bapspatil.captainchef.utils

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule

/**
 * Created by bapspatil
 */

@GlideModule
class CaptainChefGlideModule : AppGlideModule()
