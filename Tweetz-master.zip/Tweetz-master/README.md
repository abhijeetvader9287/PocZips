# Tweetz [![BuddyBuild](https://dashboard.buddybuild.com/api/statusImage?appID=5867661798f32e0100d19771&branch=master&build=latest)](https://dashboard.buddybuild.com/apps/5867661798f32e0100d19771/build/latest?branch=master)
Sample project using twitter api to search tweets (MVVM, Rxjava 2, Retrofit 2, Databinding)


