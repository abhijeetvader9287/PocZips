package com.squareup.leakcanary.tests;

import android.support.v4.app.Fragment;

public class TestFragment extends Fragment {
}
