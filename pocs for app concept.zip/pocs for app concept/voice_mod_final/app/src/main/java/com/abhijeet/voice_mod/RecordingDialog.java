package com.abhijeet.voice_mod;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
public class RecordingDialog extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recording_dialog);
    }
}
