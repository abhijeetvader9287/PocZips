package co.hypersecure.Utilities;

/**
 * Created by Awanish Raj on 04/01/16.
 */
public class Urls {

    public static final String URL_SERVER = "http://faceaccess.hyperverge.co/";

    public static final String URL_LOGIN = URL_SERVER + "/login";

    /*****/
    public static final String URL_USER_GET_RELATIVE = "/user/get";
    public static final String URL_GROUP_USER_ADD_RELATIVE = "/group/addUser";
//    public static final String URL_GROUP_USER_ADD = URL_SERVER + "v1/group/addUser";

}
