package co.hypersecure.Utilities;

import android.os.Environment;

/**
 * Created by Awanish Raj on 20/06/15.
 */
public class Constants {
    /**
        Note: Contact HyperVerge at contact@hyperverge.co for getting following 4 credentials
     */
    public static String tenantId = "";
    public static String tenantKey = "";
    public static String adminToken = "";
    public static final String groupId = "";
}
