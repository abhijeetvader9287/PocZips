<!--docs:
title: "Bidirectionality"
layout: detail
section: theming
excerpt: "Bidirectionality"
iconId: bidirectionality
path: /theming/bidirectionality/
-->

# Bidirectionality

The [bidirectionality](https://material.io/go/design-bidirectionality) engineering guidance is yet to be completed, please follow the [tracking issue](https://github.com/material-components/material-components-android/issues/92) for more information.
