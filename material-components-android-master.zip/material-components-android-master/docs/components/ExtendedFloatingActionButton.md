# Extended Floating Action Button

The [Extended Floating Action Button
component](https://material.io/go/design-extended-fab) is yet to be completed,
please follow the [tracking
issue](https://github.com/material-components/material-components-android/issues/79)
for more information.
