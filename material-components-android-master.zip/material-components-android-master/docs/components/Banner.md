# Banner

The [Banner component](https://material.io/go/design-banner) is yet to be
completed, please follow the [tracking
issue](https://github.com/material-components/material-components-android/issues/74)
for more information.
