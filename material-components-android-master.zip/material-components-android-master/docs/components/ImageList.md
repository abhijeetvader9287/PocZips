# Image List

The [Image List component](https://material.io/go/design-image-list) is yet to
be completed, please follow the [tracking
issue](https://github.com/material-components/material-components-android/issues/80)
for more information.
