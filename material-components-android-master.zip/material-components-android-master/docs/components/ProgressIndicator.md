# Progress Indicator

The [Progress Indicator
component](https://material.io/go/design-progress-indicators) is yet to be
completed, please follow the [tracking
issue](https://github.com/material-components/material-components-android/issues/83)
for more information.
