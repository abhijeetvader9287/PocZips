# Dialog

The [Dialog component](https://material.io/go/design-dialogs) is yet to be
completed, please follow the [tracking
issue](https://github.com/material-components/material-components-android/issues/77)
for more information.
