# List

The [List component](https://material.io/go/design-lists) is yet to be
completed, please follow the [tracking
issue](https://github.com/material-components/material-components-android/issues/81)
for more information.
