# Slider

The [Slider component](https://material.io/go/design-sliders) is yet to be
completed, please follow the [tracking
issue](https://github.com/material-components/material-components-android/issues/84)
for more information.
