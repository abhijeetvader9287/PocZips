# Switch

The [Switch component](https://material.io/go/design-switches) is yet to be
completed, please follow the [tracking
issue](https://github.com/material-components/material-components-android/issues/85)
for more information.
