# DataTable

The [DataTable component](https://material.io/go/design-data-tables) is yet to
be completed, please follow the [tracking
issue](https://github.com/material-components/material-components-android/issues/76)
for more information.
