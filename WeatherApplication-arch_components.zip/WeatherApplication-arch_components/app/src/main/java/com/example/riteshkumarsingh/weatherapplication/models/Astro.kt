package com.example.riteshkumarsingh.gojek.data.models

data class Astro(
	val moonset: String? = null,
	val sunrise: String? = null,
	val sunset: String? = null,
	val moonrise: String? = null
)
