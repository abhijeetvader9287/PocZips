package com.example.riteshkumarsingh.weatherapplication

/**
 * Created by riteshkumarsingh on 13/10/17.
 */
class Constants {
    companion object {
        const val BASE_URL = "http://api.apixu.com"
        // This api key is not valid, generate your own by logging in here.
        // https://www.apixu.com/
        const val key = "f308568837cd42d793d123416170610"
    }
}
