package com.ahmedabdelmeged.pagingwithrxjava.java.adapter;

/**
 * Created by Ahmed Abd-Elmeged on 2/16/2018.
 */
public interface RetryCallback {
    void retry();
}
