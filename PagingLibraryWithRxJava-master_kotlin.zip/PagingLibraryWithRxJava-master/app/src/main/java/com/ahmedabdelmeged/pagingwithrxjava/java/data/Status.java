package com.ahmedabdelmeged.pagingwithrxjava.java.data;

/**
 * Created by Ahmed Abd-Elmeged on 2/13/2018.
 */
public enum  Status {
    RUNNING,
    SUCCESS,
    FAILED
}
