package com.ahmedabdelmeged.pagingwithrxjava

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule

/**
 * Created by Ahmed Abd-Elmeged on 2/20/2018.
 */
@GlideModule
class PagingGlideModule : AppGlideModule()
