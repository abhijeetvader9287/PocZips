Icons have been taken from the following source
(original license LGPL; GPL in OpenPanodroid):

TITLE:	NUVOLA ICON THEME for KDE 3.x
AUTHOR:	David Vignoni | ICON KING
SITE:	http://www.icon-king.com
MAILING LIST: http://mail.icon-king.com/mailman/listinfo/nuvola_icon-king.com

Copyright (c)  2003-2004  David Vignoni.

David Vignoni	
e-mail :		david [at] icon-king.com
ICQ :			117761009
http:           http://www.icon-king.com
