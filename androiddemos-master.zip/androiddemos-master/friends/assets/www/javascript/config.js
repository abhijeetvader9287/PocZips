jQuery(function($){
   $.session = {'id' : null, 'date' : null};  
       
});


