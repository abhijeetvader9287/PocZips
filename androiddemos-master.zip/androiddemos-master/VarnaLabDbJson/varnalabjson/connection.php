<?php 

mysql_connect("localhost","androidjson","passwd");

mysql_select_db("categories");

mysql_query('SET CHARACTER SET utf8_bin');
mysql_query('SET NAMES utf8');

?>
