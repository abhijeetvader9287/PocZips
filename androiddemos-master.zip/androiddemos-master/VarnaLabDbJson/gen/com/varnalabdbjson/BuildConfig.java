/** Automatically generated file. DO NOT MODIFY */
package com.varnalabdbjson;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}