Speaker : Dimitar Danailov

Presentation : https://docs.google.com/presentation/d/1TdwTvJm7eQ9aIQabxJXq05Fh5n97kEjyQrwNbtcClzg/edit#slide=id.gc0f76cf6_124
Date : 08 May 2013

Video : http://www.youtube.com/watch?v=Xb2thC2WjYY&list=HL1368535327&feature=mh_lolz

====================================================================================

December 2013 
Part 2 : http://www.youtube.com/watch?v=Vx4Vq-M1Mco

January 2014 
Part 3 : http://www.youtube.com/watch?v=i5RBHoanv1s

<a href="https://github.com/dimitardanailov/androiddemos/tree/master/BeehiveAndroid" title="Beehive.bg Android Course">Beehive.bg Android Course</a>
====================================================================================

