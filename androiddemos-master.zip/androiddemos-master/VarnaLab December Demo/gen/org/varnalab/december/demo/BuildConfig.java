/** Automatically generated file. DO NOT MODIFY */
package org.varnalab.december.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}