package org.varnalab.december.demo.interfaces;

public interface iWhiskeyListInterface {
	String LISTWHISKEYURI = "https://demos-biira.appspot.com/_ah/api/birra/v1/whiskey?limit=4";
	
	String TAG_HASH_MAP_INTENT_NAME = "whiskey";
	
	String TAG_WHISKEYNAME = "name";
	
}
