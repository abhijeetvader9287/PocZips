package com.joaquimley.transporteta.presentation.home

/**
 * Created by joaquimley on 24/03/2018.
 */
enum class NavigationType {
    FAVOURITES, DASHBOARD, NOTIFICATIONS
}
