package com.joaquimley.transporteta.ui.test.util

import com.joaquimley.transporteta.ui.home.favorite.FavoritesAdapter
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.TypeSafeMatcher

/**
 * Matches the {@link CustomAdapter.ViewHolder}s in the middle of the list.
 */
