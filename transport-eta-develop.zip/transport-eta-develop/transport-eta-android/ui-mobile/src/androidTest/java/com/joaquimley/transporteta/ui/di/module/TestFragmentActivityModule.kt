package com.joaquimley.transporteta.ui.di.module

import dagger.Module

@Module
class TestFragmentActivityModule