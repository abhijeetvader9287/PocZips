package com.example.arc.core;

/**
 * @author ihsan on 2/28/18.
 */

public interface BaseViewModel {
    void onClear();
}
