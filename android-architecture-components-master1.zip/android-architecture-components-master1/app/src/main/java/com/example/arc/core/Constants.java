package com.example.arc.core;

/**
 * @author ihsan on 12/18/17.
 */

public class Constants {
    public static final String PREFERENCES = "sp:reference";
    public static final String DB = "db-source";
}
