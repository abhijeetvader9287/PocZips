package com.example.arc.model.data;

import java.util.List;

/**
 * @author ihsan on 12/3/17.
 */

@SuppressWarnings("ALL")
public class Sources {
    private List<Source> sources;

    public List<Source> getSources() {
        return sources;
    }
}
