package com.example.arc.model.data;

import java.util.List;

/**
 * @author ihsan on 12/19/17.
 */

@SuppressWarnings("ALL")
public class Articles {
    private List<Article> articles;

    public List<Article> getArticles() {
        return articles;
    }
}
