package com.mindorks.framework.mvp.di

import javax.inject.Qualifier

/**
 * Created by jyotidubey on 11/01/18.
 */
@Qualifier
@Retention annotation class PreferenceInfo