# Movify
Movify is an android application built using MVP architecture , RxJava2, ButterKnife and Glide

## This application is part of the tutorial series - Simple Android App with MVP, RxJava2 and Retrofit

Part 1 - https://goo.gl/oKuQuU

Part 2 - https://goo.gl/xFK8zc

![1_wkvuxjk8mwafw2ko72orzw](https://user-images.githubusercontent.com/7893859/34636315-a68fd92c-f2c4-11e7-82a6-719ae48fcf19.png)





