package in.androidmate.anujgupta.movify.ui.main;

import in.androidmate.anujgupta.movify.models.MovieResponse;

/**
 * Created by anujgupta on 26/12/17.
 */

public interface MainPresenterInterface {

    void getMovies();
}
