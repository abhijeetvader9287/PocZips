package in.androidmate.anujgupta.movify.di.components;

import dagger.Component;
import in.androidmate.anujgupta.movify.di.modules.ApplicationModule;

/**
 * Created by anujgupta on 22/01/18.
 */


@Component(modules = ApplicationModule.class)
public interface ApplicationComponent {


}
