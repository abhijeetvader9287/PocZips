package com.tolmachevroman.restaurants.datasources.webservice

/**
 * Created by romantolmachev on 22/11/2017.
 */
data class Error(val code: Int, val message: String)