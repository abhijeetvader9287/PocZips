package biz.eventually.atpl.data.network

/**
 * Created by Thibault de Lambilly on 18/06/2017.
 */
data class FollowNetwork(val good: Int, val wrong: Int)