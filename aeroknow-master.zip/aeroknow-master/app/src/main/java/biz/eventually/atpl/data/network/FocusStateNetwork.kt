package biz.eventually.atpl.data.network

/**
 * Created by Thibault de Lambilly on 17/06/17.
 */
data class FocusStateNetwork(val focus: Boolean?)