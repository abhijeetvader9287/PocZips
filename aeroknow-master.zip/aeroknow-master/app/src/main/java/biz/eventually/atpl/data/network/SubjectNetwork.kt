package biz.eventually.atpl.data.network

/**
 * Created by Thibault de Lambilly on 21/03/17.
 */
data class SubjectNetwork(val id: Long, val name: String, val topics: List<TopicNetwork>?)