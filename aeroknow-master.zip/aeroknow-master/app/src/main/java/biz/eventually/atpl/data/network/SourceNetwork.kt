package biz.eventually.atpl.data.network

/**
 * Created by Thibault de Lambilly on 21/03/17.
 */
data class SourceNetwork(val id: Long, val name: String)