package biz.eventually.atpl.data.network

/**
 * Created by Thibault de Lambilly on 21/03/17.
 */
data class AnswerNetwork(val id: Long, val value: String, val good: Boolean = false)