#!/usr/bin/env bash
./gradlew build --refresh-dependencies
