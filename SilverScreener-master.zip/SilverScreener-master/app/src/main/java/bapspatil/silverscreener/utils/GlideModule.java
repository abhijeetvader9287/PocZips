package bapspatil.silverscreener.utils;

import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by bapspatil
 */

@com.bumptech.glide.annotation.GlideModule
public class GlideModule extends AppGlideModule {

}
