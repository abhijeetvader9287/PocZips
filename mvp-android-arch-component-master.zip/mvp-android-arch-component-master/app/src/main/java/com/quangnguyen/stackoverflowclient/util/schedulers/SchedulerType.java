package com.quangnguyen.stackoverflowclient.util.schedulers;

public enum SchedulerType {
  IO, UI
}
