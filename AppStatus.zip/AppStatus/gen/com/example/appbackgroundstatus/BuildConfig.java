/** Automatically generated file. DO NOT MODIFY */
package com.example.appbackgroundstatus;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}