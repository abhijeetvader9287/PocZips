package com.codemate.booklibrary.ui;

import com.codemate.booklibrary.data.Book;

import java.util.List;

public interface MainView {
    void showBooks(List<Book> books);
}
