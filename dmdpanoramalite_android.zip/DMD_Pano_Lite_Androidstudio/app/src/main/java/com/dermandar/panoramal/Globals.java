package com.dermandar.panoramal;

public class Globals {
	public static final String EQUI_FOLDER_NAME = "Panoramas";
}
