package com.simplemobiletools.contacts.pro.models

data class IM(var value: String, var type: Int, var label: String)
