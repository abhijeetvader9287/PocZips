package com.simplemobiletools.contacts.pro.models

data class BlockedNumber(val id: Long, val number: String, val normalizedNumber: String)
