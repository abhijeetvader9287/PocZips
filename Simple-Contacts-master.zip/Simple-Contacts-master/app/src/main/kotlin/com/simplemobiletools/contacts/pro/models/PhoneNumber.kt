package com.simplemobiletools.contacts.pro.models

data class PhoneNumber(var value: String, var type: Int, var label: String, var normalizedNumber: String?)
