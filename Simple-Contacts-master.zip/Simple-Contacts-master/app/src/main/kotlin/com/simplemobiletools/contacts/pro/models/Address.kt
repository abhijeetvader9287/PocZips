package com.simplemobiletools.contacts.pro.models

data class Address(var value: String, var type: Int, var label: String)
