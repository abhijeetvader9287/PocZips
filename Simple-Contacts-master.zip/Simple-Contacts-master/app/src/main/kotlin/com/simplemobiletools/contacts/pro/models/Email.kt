package com.simplemobiletools.contacts.pro.models

data class Email(var value: String, var type: Int, var label: String)
