package com.simplemobiletools.contacts.pro.models

data class Event(var value: String, var type: Int)
