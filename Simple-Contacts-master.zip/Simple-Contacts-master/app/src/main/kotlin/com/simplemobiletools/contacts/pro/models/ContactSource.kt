package com.simplemobiletools.contacts.pro.models

data class ContactSource(var name: String, var type: String)
