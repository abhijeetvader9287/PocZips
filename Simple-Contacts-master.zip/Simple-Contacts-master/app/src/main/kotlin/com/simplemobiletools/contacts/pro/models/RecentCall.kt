package com.simplemobiletools.contacts.pro.models

data class RecentCall(var id: Int, var number: String, var dateTime: String, var name: String?)
