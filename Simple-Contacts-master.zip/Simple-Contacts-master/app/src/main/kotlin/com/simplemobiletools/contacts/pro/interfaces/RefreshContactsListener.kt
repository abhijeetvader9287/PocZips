package com.simplemobiletools.contacts.pro.interfaces

interface RefreshContactsListener {
    fun refreshContacts(refreshTabsMask: Int)
}
